<head>
<title>php work</title>
<style>
 input{
 padding:10px;
 margin:10px;}
</style>
</head>
<body>
	<form action="check.php" method="GET">
		<fieldset style="width:100px">
		<legend>login</legend>
		<table>
				
			
			<tr>
				<td><h2>email:</h2></td>
				<td><input type="email" name="email"></td>
			</tr>
            </br>
			<tr>
				<td><h2>password:</h2></td>
				<td><input type="password" name="password"></td>
			</tr>
            <tr>
			<td><input type="submit" name="submit" value="login"></td>
			</tr>
</fieldset>
</form>
	