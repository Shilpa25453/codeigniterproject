<!DOCTYPE html>
<html>
<head>
	<title>KERALA TRAVELMATE</title>
	<link rel="stylesheet" href="css/style.css">
	<style>
		

	</style>
</head>
<body class="bi3">

   <nav class="menubar">
	 
      <ul>
	    <li><h1>KERALA TRAVELMATE       user</h1></li>
	    <li><a href="index.php">Home</a></li>
		<li><a href="aboutus.php">About us</a></li>
	    <li><a href="#">Profile</a></li>
		<li><a href="userpackview.php">Packages</a></li>
		<li><a href="#">Contact us</a></li>
		<li><a href="index.php">Logout</a></li>
	  </ul> 
    </nav> 	  
</body>
</html>