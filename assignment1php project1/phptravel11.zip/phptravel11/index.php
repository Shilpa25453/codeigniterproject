<!DOCTYPE html>
<html>
<head>
	<title>KERALA TRAVELMATE</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css">
</head>
<style>
	.footer {
  left: 0;
  bottom: 0;
  width: 100%;
  height:20%;
  background-color:black;
  color:white;
  text-align: center;
}

	
</style>
<body >
	<section>

   <nav class="menubar">
	 
      <ul>
	    <li><h1>KERALA TRAVELMATE</h1></li>
	    <li><a href="index.php">Home</a></li>
		<li><a href="aboutus.php">About us</a></li>
	    <li><a href="registration.php">Sign in</a></li>
		<li><a href="loginform.php">Login</a></li>
		<li><a href="viewpackindex.php">Packages</a></li>
		<li><a href="#im">Gallery</a></li>
		<li><a href="#cont">Contact us</a></li>
	  </ul> 
    </nav>
    </section> 
     
     <section class="bi vh-100">
     	
     </section>
     <section class="py-5" id="im">
     	<div class="container">
     		<h1 class="text-center">Our Gallery</h1>
     		<div class="row">
     			<div class="col-4">
     				<img src="img/g2.jpeg" class="img-fluid">
     			</div>
     			<div class="col-4">
     				<img src="img/g6.jpg" class="img-fluid">
     			</div>
     			<div class="col-4">
     				<img src="img/56.jpg" class="img-fluid">
     			</div>
     		</div>
     		<div class="row py-5">
     			<div class="col-4">
     				<img src="img/13.jpg" class="img-fluid">
     			</div>
     			<div class="col-4">
     				<img src="img/ss.jpg" class="img-fluid">
     			</div>
     			<div class="col-4">
     				<img src="img/bg3.jpeg" class="img-fluid">
     			</div>

     			
     		</div>
     		
     	</div>
     	
     </section>

<section class="py-5">
<div class="footer" id="cont">
  <h3>Contact Us</h3>
  PKM Tours and Travels</br>
  Bhavani Building
  Sreekaryam Trivandrum</br>
 	phone:+91 89656423</br>
  email:pkmtours@gmail.com
</div>
</section>

   	
<script src="css/bootstrap/js/bootstrap.bundle.min.js"></script>	 
</body>
</html>