<!DOCTYPE html>
<html>
<head>
	<title>KERALA TRAVELMATE</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<style>

</style>
<body class="bi8">
<!-- navigation started-->
   <nav class="menubar">
	 
      <ul>
	    <li><h1>KERALA TRAVELMATE                Admin</h1></li>
	    <li><a href="index.php">Home</a></li>
		<li><a href="viewuser.php">User</a></li>
		<li><a href="packagereg.php">Add Packages</a></li>
		<li><a href="viewpackage.php">View Packages</a></li>
	    <li><a href="#"></a></li>
		<li><a href="index.php">Logout</a></li>
		
	  </ul> 
    </nav> 	  
</body>
</html>