<!DOCTYPE html>
<html>
<head>
	<title>KERALA TRAVELMATE</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body class="bi1">
<!-- navigation started-->
   <nav class="menubar">
	 
      <ul>
	    <li><h1>KERALA TRAVELMATE</h1></li>
	    <li><a href="index.php"> Home</a></li>
		<li><a href="aboutus.html"></a></li>
	    
	  </ul> 
    </nav> 	
		<div class="about">
		<h1>About us</h1>
		<p>This is a Website for Kerala Tourism Named "KERALA TRAVELMATE".This site contains Exhaustive informations on God's Own Country-Kerala.We are providing interesting tourist spots in Kerala With fair cost.These Packages include your full accomodation,food for your whole trip.You can get a Guide facilities for your entire tour.This is more simple and interactive site.You can get your Dream destination in a mouse click.</p>
		</div>
		 
		
</body>
</html>