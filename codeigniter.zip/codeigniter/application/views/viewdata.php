<!DOCTTYPE html>
<html>
<head>
	<title></title>
	<style>
		table,th,td{
			border:1px solid;

		}
	</style>
	</head>
	<body>

		<table>
			<thead>
			<tr>
			
				<th>name</th>
				<th>address</th>
				<th>gender</th>
				<th>age</th>
				<th>email</th>
			
			</tr>
			</thead>
		<?php
		if($n->num_rows()>0)
		{
			foreach($n->result()as $row)
		{
		?>
		<tr>
		<td><?php echo $row->name;?></td>
		<td><?php echo $row->address;?></td>
		<td><?php echo $row->gender;?></td>
		<td><?php echo $row->age;?></td>
		<td><?php echo $row->emailid;?></td>
		<?php
		if($row->status==1)
		{
			?>
			<td>approved</td><td><a href="<?php echo base_url()?>main/reject/<?php echo $row->id;?>">reject</a></td>
			<?php
		}
		elseif($row->status==2)
		{
			?>
			<td>rejected</td><td><a href="<?php echo base_url()?>main/approve/<?php echo $row->id;?>">approve</a></td>
			<?php
		}
		else
		{
			?>

		
		<td><a href="<?php echo base_url()?>main/approve/<?php echo $row->id;?>">approve</a></td>
		<td><a href="<?php echo base_url()?>main/reject/<?php echo $row->id;?>">reject</a></td>
		</tr>
		<?php
}
}}
else
{
	?>
	<tr>
		<td>no data found</td>
		</tr>
	<?php
}

?>
	
	</table>
</form>
	</body>
	</html>

