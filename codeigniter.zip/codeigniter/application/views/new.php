<!DOCTTYPE html>
	<html>
	<head>
		<title></title>
		<style>
		</style>
	</head>
	<body>
	<h1>WELCOME PHP</h1>
	<h2>HELLO WORLD</h2>
</body>
</html>


